package com.project_EyeCare.EyeCare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EyeCareApplication {

	public static void main(String[] args) {
		SpringApplication.run(EyeCareApplication.class, args);
	}

}
